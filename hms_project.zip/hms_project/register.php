<?php
// Include database connection
require 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $room_type = $_POST['room_type'];

    // Insert into database
    $sql = "INSERT INTO users (first_name, last_name, gender, dob, email, phone, username, password, room_type)
            VALUES ('$first_name', '$last_name', '$gender', '$dob', '$email', '$phone', '$username', '$password', '$room_type')";

    if ($conn->query($sql) === TRUE) {
        echo "Registration successful!";
        header("Location: success.html");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
