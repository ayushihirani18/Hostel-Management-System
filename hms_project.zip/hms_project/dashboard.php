<?php
session_start();

// Assuming the user is logged in and user details are in the session
if (!isset($_SESSION['username'])) {
    header('Location: login.php'); // Redirect to login if not logged in
    exit;
}

// Include DB connection
include('db_connect.php');

// Get user details from database
$username = $_SESSION['username'];
$sql = "SELECT * FROM users WHERE username = '$username'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    // Assign random room number if not already assigned
    if (empty($user['room_number'])) {
        $room_number = generateRandomRoomNumber();  // Custom function to generate room number
        $update_sql = "UPDATE users SET room_number = '$room_number' WHERE username = '$username'";
        $conn->query($update_sql);
        $user['room_number'] = $room_number;
    }
} else {
    echo "User not found.";
    exit;
}

// Function to generate random room number
function generateRandomRoomNumber() {
    $ranges = [
        range(1, 20),
        range(100, 120),
        range(200, 220),
        range(300, 320),
        range(400, 420),
        range(500, 520),
        range(600, 620),
        range(700, 720)
    ];
    // Select a random range and pick a random room number from that range
    $selected_range = $ranges[array_rand($ranges)];
    return $selected_range[array_rand($selected_range)];
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
        }
       .section {
            border: 1px solid #ccc;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 10px;
        }
        .user-details, .payment-section, .service-section {
            margin-bottom: 20px;
        }
        .qr-code {
            width: 150px;
            height: 150px;
        }
        .room-number {
            font-size: 24px;
            color: #2c3e50;
            margin-top: 10px;
        }
        .welcome-header {
            font-size: 28px;
            font-weight: bold;
        }
        body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

.dashboard-container {
    max-width: 600px;
    margin: 50px auto;
    padding: 20px;
    background-color: #fff;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

h1 {
    color: #333;
}

p {
    font-size: 18px;
    margin: 10px 0;
}

a {
    display: inline-block;
    margin-top: 20px;
    padding: 10px 20px;
    background-color: #266eba;
    color: #fff;
    text-decoration: none;
    border-radius: 5px;
}

a:hover {
    background-color: #0056b3;
}
    
    </style>
</head>
<body>

<div class="dashboard-container">
    <!-- Welcome Section -->
    <div class="section user-details">
        <h2 class="welcome-header">Welcome, <?php echo htmlspecialchars($user['username']); ?>!</h2>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
        <p><strong>Phone:</strong> <?php echo htmlspecialchars($user['phone']); ?></p>
        <p class="room-number"><strong>Room Number:</strong> <?php echo $user['room_number']; ?></p>
    </div>

    <!-- Payment Section -->
    <div class="section payment-section">
        <h3>Pay your Hostel Fee</h3>
        <p>Scan the QR code below to pay your hostel fees:</p>
        <img src = "image/qrcode.jpg" class="qr-code">
        <p><strong>Amount Due:</strong> </p>
    </div>

    <div>
        <a href ="index.html">Log out</a>
    </div>


</div>

</body>
</html>

