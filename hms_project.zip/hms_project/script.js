// Get modals and trigger elements
var registerModal = document.getElementById("registerModal");
var loginModal = document.getElementById("loginModal");
var registerLink = document.getElementById("registerLink");
var loginLink = document.getElementById("loginLink");
var registerClose = document.getElementById("registerClose");
var loginClose = document.getElementById("loginClose");

// Show registration modal when clicking register link
registerLink.onclick = function() {
    registerModal.style.display = "block";
    loginModal.style.display = "none"; // Hide login modal if open
}

// Show login modal when clicking login link
loginLink.onclick = function() {
    loginModal.style.display = "block";
    registerModal.style.display = "none"; // Hide registration modal if open
}

// Hide modals when clicking the close button
registerClose.onclick = function() {
    registerModal.style.display = "none";
}

loginClose.onclick = function() {
    loginModal.style.display = "none";
}

// Hide modals when clicking outside of the modal
window.onclick = function(event) {
    if (event.target == registerModal) {
        registerModal.style.display = "none";
    } else if (event.target == loginModal) {
        loginModal.style.display = "none";
    }
}

// Form validation function
function validateForm() {
    var email = document.getElementById("email").value;
    var phone = document.getElementById("phone").value;
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("confirm_password").value;

    // Email validation regex
    var emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailPattern.test(email)) {
        document.getElementById("emailError").innerText = "Please enter a valid email address.";
        return false;
    } else {
        document.getElementById("emailError").innerText = "";
    }

    // Phone number validation
    if (phone.length !== 10) {
        document.getElementById("phoneError").innerText = "Phone number must be exactly 10 digits.";
        return false;
    } else {
        document.getElementById("phoneError").innerText = "";
    }

    

    // Confirm password check
    if (password !== confirmPassword) {
        document.getElementById("confirmPasswordError").innerText = "Passwords do not match.";
        return false;
    } else {
        document.getElementById("confirmPasswordError").innerText = "";
    }

    return true; // Allow form submission if all checks pass
}
