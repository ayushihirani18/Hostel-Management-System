// Create a lightbox effect when clicking on gallery images
const galleryImages = document.querySelectorAll('.gallery-image');

galleryImages.forEach(image => {
    image.addEventListener('click', () => {
        const lightbox = document.createElement('div');
        lightbox.id = 'lightbox';
        document.body.appendChild(lightbox);

        const img = document.createElement('img');
        img.src = image.src;
        img.style.width = '80%';
        img.style.height = 'auto';
        lightbox.appendChild(img);

        lightbox.addEventListener('click', () => {
            lightbox.remove(); // Close lightbox on click
        });
    });
});

// This script could handle booking clicks or other dynamic behaviors
const bookButtons = document.querySelectorAll('.book-now');
bookButtons.forEach(button => {
    button.addEventListener('click', () => {
        alert('Booking feature is coming soon!');
    });
});