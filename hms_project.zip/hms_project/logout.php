<?php
session_start();

// Destroy all session data and redirect to login page
session_destroy();
header("Location: index.html");
exit;
?>
