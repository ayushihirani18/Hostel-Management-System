<?php
session_start(); // Important to start the session

include('db_connect.php');  // Make sure you have the correct path to your DB config

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Fetch and sanitize input values
    $username = mysqli_real_escape_string($conn, $_POST['login_username']);
    $password = mysqli_real_escape_string($conn, $_POST['login_password']);

    // Check if the username exists in the database
    $sql = "SELECT * FROM users WHERE username = '$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Compare password (in real projects, use password_verify() for hashed passwords)
        if ($password === $row['password']) {
            // Set session variables
            $_SESSION['username'] = $username;
            $_SESSION['user_id'] = $row['id'];

            // Redirect to dashboard.php
            header("Location: dashboard.php");
            exit;
        } else {
            // Password is incorrect
            echo "Invalid password.";
        }
    } else {
        // No user found with that username
        echo "Username not found. Please try again or register.";
    }

    // Close the database connection
    $conn->close();
}
?>
