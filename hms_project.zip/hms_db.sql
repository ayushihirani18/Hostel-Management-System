-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 23, 2024 at 12:17 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hms_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(6) UNSIGNED NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `feedback` text NOT NULL,
  `submission_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `email`, `feedback`, `submission_date`) VALUES
(1, '', '', '', '2024-10-17 13:59:11'),
(2, '', '', '', '2024-10-17 14:01:52'),
(3, 'Ayushi Hirani', 'ayushihirani3@gmail.com', 'security', '2024-10-17 14:04:29'),
(4, 'kamya gorasiya', 'kamyagorasiya@gmail.com', 'nice food menu.', '2024-10-17 16:02:20'),
(5, 'Ayushi Deepak ', 'ayushihirani.22.cse@iite.indusuni.ac.in', 'hello thanks for feedback', '2024-10-17 18:11:22'),
(6, 'xyz', 'xyz@gmail.com', 'feedback', '2024-10-17 18:13:56'),
(7, 'dhanvi', 'dhanvi@gmail.com', 'xyz', '2024-10-21 03:26:04');

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `room_number` int(11) NOT NULL,
  `status` enum('available','occupied') DEFAULT 'available'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`room_number`, `status`) VALUES
(1, 'occupied'),
(2, 'occupied'),
(3, 'available'),
(4, 'available'),
(5, 'available'),
(6, 'available'),
(7, 'available'),
(8, 'available'),
(9, 'available'),
(10, 'available'),
(11, 'available'),
(12, 'available'),
(13, 'available'),
(14, 'available'),
(15, 'available'),
(16, 'available'),
(17, 'available'),
(18, 'available'),
(19, 'available'),
(20, 'available'),
(100, 'available'),
(101, 'available'),
(102, 'available'),
(103, 'available'),
(104, 'available'),
(105, 'available'),
(106, 'available'),
(107, 'available'),
(108, 'available'),
(109, 'available'),
(110, 'available'),
(111, 'available'),
(112, 'available'),
(113, 'available'),
(114, 'available'),
(115, 'available'),
(116, 'available'),
(117, 'available'),
(118, 'available'),
(119, 'available'),
(120, 'available'),
(200, 'available'),
(201, 'available'),
(202, 'available'),
(203, 'available'),
(204, 'available'),
(205, 'available'),
(206, 'available'),
(207, 'available'),
(208, 'available'),
(209, 'available'),
(210, 'available'),
(211, 'available'),
(212, 'available'),
(213, 'available'),
(214, 'available'),
(215, 'available'),
(216, 'available'),
(217, 'available'),
(218, 'available'),
(219, 'available'),
(220, 'available'),
(300, 'available'),
(301, 'available'),
(302, 'available'),
(303, 'available'),
(304, 'available'),
(305, 'available'),
(306, 'available'),
(307, 'available'),
(308, 'available'),
(309, 'available'),
(310, 'available'),
(311, 'available'),
(312, 'available'),
(313, 'available'),
(314, 'available'),
(315, 'available'),
(316, 'available'),
(317, 'available'),
(318, 'available'),
(319, 'available'),
(320, 'available'),
(700, 'available'),
(701, 'available'),
(702, 'available'),
(703, 'available'),
(704, 'available'),
(705, 'available'),
(706, 'available'),
(707, 'available'),
(708, 'available'),
(709, 'available'),
(710, 'available'),
(711, 'available'),
(712, 'available'),
(713, 'available'),
(714, 'available'),
(715, 'available'),
(716, 'available'),
(717, 'available'),
(718, 'available'),
(719, 'available'),
(720, 'available');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(6) UNSIGNED NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `dob` date NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `room_type` varchar(20) NOT NULL,
  `registration_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `room_number` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `gender`, `dob`, `email`, `phone`, `username`, `password`, `room_type`, `registration_date`, `room_number`) VALUES
(5, 'abc', 'def', 'female', '2004-09-30', 'abcdef@gmail.com', '9876543210', 'abcdef', 'abcdef', 'single', '2024-10-17 14:34:25', 1),
(6, 'kamya', 'gorasiya', 'female', '2000-09-22', 'kamyagorasiya@gmail.com', '9157885666', 'kamyagorasiya', 'kamya1234', 'single', '2024-10-17 15:58:00', 207),
(7, 'ayushi', 'hirani', 'female', '2004-09-30', 'ayushihirani3@gmail.com', '9876543210', 'ayushi', 'ayushi', 'single', '2024-10-17 16:39:24', 2),
(9, 'xyz', '123', 'female', '2003-02-01', 'xyz@gmail.com', '1234567890', 'xyz123', 'xyz123', 'single', '2024-10-17 18:15:13', 319),
(10, 'Dhanvi', 'Prajapati', 'female', '2004-09-21', 'dhanvi@gmail.com', '9638527410', 'Dhanvi', 'dhanvi123', 'double', '2024-10-21 03:24:09', 106),
(11, 'hardi ', 'patel', 'female', '2004-05-26', 'hardipatel864@gmail.com', '9313698039', 'hardi', 'hardipatel', 'double', '2024-10-21 06:44:17', 16);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`room_number`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
